GOOGLEAPITOKEN="AIzaSyDC46tmAnWSDdjAb2SFQFXOMSWSTsW2_eQ"
SOFFICE="/Applications/LibreOffice.app/Contents/MacOS/soffice"
FINDER="open"
